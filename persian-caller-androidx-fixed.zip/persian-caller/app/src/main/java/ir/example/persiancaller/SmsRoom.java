package ir.example.persiancaller;
import android.app.*;
import android.content.*;
import android.media.MediaPlayer;
import android.os.*;
import android.widget.*;
import java.io.File;
import java.util.List;
import java.util.regex.*;

/** Foreground, unlocked conversational SMS session. Nothing pending survives onStop. */
public final class SmsRoom extends Activity {
 TextView log;EditText input;PersianEar ear;MediaPlayer player;SmsCore.Msg target;String draft="";int generation;boolean active,awaitBody,started;long deadline;
 void button(LinearLayout l,String label,Runnable r){Button b=new Button(this);b.setText(label);l.addView(b);b.setOnClickListener(v->r.run());}
 public void onCreate(Bundle s){super.onCreate(s);getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);LinearLayout l=new LinearLayout(this);l.setPadding(24,24,24,24);l.setOrientation(1);ScrollView sc=new ScrollView(this);sc.addView(l);setContentView(sc);log=new TextView(this);l.addView(log);input=new EditText(this);input.setHint("رحمتی در پیام چی نوشته؟");l.addView(input);button(l,"گفتن فرمان",()->{interrupt();listen();});button(l,"اجرای متن",()->{interrupt();String s1=input.getText().toString();input.setText("");command(s1);});button(l,"صندوق و تنظیم پیامک پیش‌فرض",()->startActivity(new Intent(this,TextInbox.class)));}
 protected void onResume(){super.onResume();active=true;if(!started){started=true;open();}}
 void open(){if(!SmsCore.held(this)){log.setText("ابتدا کارا را برنامهٔ پیامک پیش‌فرض کن.");return;}say("باز کردم. پیام چه کسی را بخوانم؟",true);}
 boolean unlocked(){return active&&!getSystemService(KeyguardManager.class).isDeviceLocked();}
 void interrupt(){generation++;if(ear!=null){ear.stop();ear=null;}if(player!=null){player.release();player=null;}}
 protected void onStop(){active=false;interrupt();target=null;draft="";awaitBody=false;deadline=0;log.setText("");input.setText("");super.onStop();}
 void say(String text,boolean next){interrupt();if(!unlocked())return;log.setText(text);final int id=generation;new Thread(()->{try{File f=EmbeddedVoice.privateUtterance(this,text);runOnUiThread(()->{if(generation!=id||!unlocked()){f.delete();return;}try{player=new MediaPlayer();player.setDataSource(f.getPath());f.delete();player.prepare();player.setOnCompletionListener(p->{interrupt();if(next&&unlocked())listen();});player.start();}catch(Exception e){f.delete();interrupt();log.append("\nپخش نشد. گفتن فرمان را بزن.");}});}catch(Exception|LinkageError e){runOnUiThread(()->{if(id==generation)log.append("\nپخش نشد. گفتن فرمان را بزن.");});}},"sms-speech").start();}
 void listen(){if(!unlocked())return;if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=0){requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},4);return;}ear=new PersianEar();ear.start(this,true,new PersianEar.Events(){public void ready(){log.append("\n🎙 حالا بگو…");}public void result(String s){if(!s.isEmpty())command(s);else log.append("\nچیزی نشنیدم؛ گفتن فرمان را بزن.");}public void error(String e){log.append("\n"+e);}});}
 public void onRequestPermissionsResult(int r,String[] p,int[] v){super.onRequestPermissionsResult(r,p,v);if(r==4&&v.length>0&&v[0]==0)listen();}
 void preview(String body){awaitBody=false;deadline=0;draft="";if(body.length()>100||body.isEmpty()||target.title.length()>40){say("برای بازخوانی کامل، یک جواب کوتاه تر بگو.",true);return;}draft=body;deadline=SystemClock.elapsedRealtime()+120000;say("برای "+target.title+" نوشتم: "+body+". بفرستم؟",true);}
 void command(String raw){if(!unlocked())return;String s=SmsCore.norm(raw).replaceFirst("^کارا\\s+","");try{
 if(s.equals("لغو")||s.equals("نه")){draft="";awaitBody=false;deadline=0;say("لغو کردم.",false);return;}
 if(s.equals("بفرست")||s.equals("ارسال کن")){String d=draft;draft="";awaitBody=false;if(d.isEmpty()||target==null||SystemClock.elapsedRealtime()>deadline){say("جواب تأییدشده‌ای ندارم. دوباره جواب را بگو.",true);return;}SmsCore.send(this,target.number,d,target.sub);target=null;say("جواب در صف ارسال قرار گرفت.",false);return;}
 draft="";deadline=0;
 if(s.matches("پیامک ?ها (رو |را )?باز کن")){target=null;awaitBody=false;open();return;}
 Matcher reply=Pattern.compile("^(?:این جواب (?:رو|را) بده|جواب بده|در جواب بنویس)(?:\\s+(.*))?$").matcher(s);
 if(reply.matches()||awaitBody){if(target==null||!target.writable){awaitBody=false;say("اول یک پیام از شمارهٔ قابل پاسخ انتخاب کن.",true);return;}if(reply.matches()&&reply.group(1)==null){awaitBody=true;say("متن جواب را بگو.",true);}else preview(reply.matches()?reply.group(1):raw.trim());return;}
 if(s.equals("جواب پیشنهاد بده")&&target!=null){if(!target.writable){say("به این فرستنده نمی‌شود پاسخ داد.",true);return;}int id=++generation;log.setText("در حال پیشنهاد جواب…");String message=target.body;DraftBrain.suggest(this,message,result->{if(id!=generation||!unlocked())return;if(result==null){say("مدل آماده نیست. خودت جواب را بگو.",true);return;}preview(result);});return;}
 target=null;String who=s.replaceFirst("^پیام\\s+","").replaceFirst("\\s+(?:(?:در )?پیام )?(?:چی نوشته|چی گفته|(?:رو |را )?بخون)$", "").trim();List<SmsCore.Msg> msgs=SmsCore.find(this,who);if(msgs.size()>1){say("چند شماره با این نام پیدا کردم. شمارهٔ دقیق را وارد کن.",true);return;}if(!msgs.isEmpty())target=msgs.get(0);
 if(target==null){say("پیام دریافتی پیدا نکردم. اسم کامل مخاطب یا شماره را بگو.",true);return;}String body=target.body;String excerpt=body.length()>100?body.substring(0,100)+"، ادامه دارد":body;say(target.title+" نوشته: "+excerpt,true);log.setText(target.title+"\n"+body);
 }catch(Exception ex){target=null;draft="";awaitBody=false;say("نقش پیامک پیش‌فرض، اجازه مخاطبین و سیم‌کارت پیامک را بررسی کن.",false);}}
}
