package ir.example.persiancaller;
import android.app.Activity;
import android.os.Bundle;
import android.telecom.*;
import android.widget.*;
public class CallScreen extends Activity {
 LinearLayout box; final Runnable redraw=this::render;
 public void onCreate(Bundle b){super.onCreate(b);box=new LinearLayout(this);box.setOrientation(1);box.setPadding(32,80,32,48);ScrollView scroll=new ScrollView(this);scroll.addView(box);setContentView(scroll);Look.safe(scroll);}
 public void onResume(){super.onResume();KaraCalls.refresh=redraw;render();}public void onPause(){if(KaraCalls.refresh==redraw)KaraCalls.refresh=null;super.onPause();}
 void label(String s){TextView t=new TextView(this);t.setText(s);box.addView(t);}void button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());box.addView(b);}
 void render(){KaraCalls k=KaraCalls.live;if(k==null||k.calls.isEmpty()){finish();return;}box.removeAllViews();Look.header(box);for(Call c:k.calls){android.net.Uri u=c.getDetails().getHandle();label(u==null?"شماره ناشناس":u.getSchemeSpecificPart());if(c.getState()==Call.STATE_RINGING){button("پاسخ دستی",()->k.manual(c));button("رد تماس",()->c.reject(false,null));}else{button("قطع تماس",c::disconnect);if(c.getState()==Call.STATE_ACTIVE){CallAudioState a=k.getCallAudioState();boolean speaker=a!=null&&a.getRoute()==CallAudioState.ROUTE_SPEAKER;button(speaker?"برگشت به گوشی":"روشن کردن بلندگو",()->k.route(!speaker));}}}label(k.routing);}
}
