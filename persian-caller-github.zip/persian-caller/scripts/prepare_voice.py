"""Download verified upstream archives at BUILD time, never on the phone."""
from pathlib import Path
import hashlib
import shutil
import tarfile
import urllib.request
import time

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / '.voice-downloads'
CACHE.mkdir(exist_ok=True)
ASSETS = ROOT / 'app/src/main/assets/voice'
LIBS = ROOT / 'app/src/main/jniLibs'
MODEL_URL = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-fa-haaniye_low.tar.bz2'
NATIVE_URL = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.12.20/sherpa-onnx-v1.12.20-android.tar.bz2'

def download(name, url, digest):
    dest = CACHE / name
    if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest() == digest:
        return dest
    for attempt in range(4):
        try:
            print('Downloading', url, flush=True)
            with urllib.request.urlopen(url, timeout=120) as src, dest.open('wb') as out:
                shutil.copyfileobj(src, out)
            if hashlib.sha256(dest.read_bytes()).hexdigest() != digest:
                raise RuntimeError('SHA256 verification failed: ' + name)
            return dest
        except Exception:
            dest.unlink(missing_ok=True)
            if attempt == 3:
                raise
            time.sleep(5)

def unpack(archive, choose, max_files=None):
    print('Unpacking', archive.name, flush=True)
    copied = 0
    # Copy regular files only; do not trust archive paths or symlinks.
    with tarfile.open(archive, 'r|bz2') as tar:
        for item in tar:
            if not item.isfile():
                continue
            parts = Path(item.name).parts
            if '..' in parts or Path(item.name).is_absolute():
                raise RuntimeError('Unsafe archive path')
            target = choose(parts)
            if target is None:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(item) as source, target.open('wb') as out:
                shutil.copyfileobj(source, out)
            copied += 1
            if max_files is not None and copied >= max_files:
                break

model = download('model.tar.bz2', MODEL_URL, '0a329e886eff1d0b4ec0b503a36fd7d8ce218c2ab7e69c068a02ebc039c6eaa1')
native = download('native.tar.bz2', NATIVE_URL, '5fb837e72c9dae6fe06d208dc97f2f6d715f7e5e476a6e36d1549e49c7e209d4')
unpack(model, lambda p: ASSETS.joinpath(*p[1:]) if len(p)>1 and p[0]=='vits-piper-fa-haaniye_low' else None)
unpack(native, lambda p: LIBS.joinpath(*p[1:]) if len(p)==3 and p[0]=='jniLibs' and p[1] in ('arm64-v8a','armeabi-v7a') and p[2].endswith('.so') else None, max_files=8)
for required in [ASSETS/'fa-haaniye_low.onnx', ASSETS/'tokens.txt', ASSETS/'espeak-ng-data/phontab', LIBS/'arm64-v8a/libsherpa-onnx-jni.so', LIBS/'armeabi-v7a/libonnxruntime.so']:
    if not required.is_file():
        raise RuntimeError('Missing required file: ' + str(required))
notices = ROOT / 'app/src/main/assets/legal'
notices.mkdir(parents=True, exist_ok=True)
shutil.copytree(ROOT / 'licenses', notices / 'licenses', dirs_exist_ok=True)
for name in ('LICENSE', 'THIRD_PARTY_NOTICES.md'):
    shutil.copy2(ROOT / name, notices / name)
print('Offline Persian voice ready.', flush=True)

import zipfile
fa = 'vosk-model-small-fa-0.42'
archive = download(fa+'.zip', 'https://alphacephei.com/vosk/models/'+fa+'.zip', '977cb5faa538f3a835ccfd35f5f6d8284b5c450b89c700b9bd4736b66536ad46')
with zipfile.ZipFile(archive) as z:
    for entry in z.infolist():
        parts = Path(entry.filename).parts
        if len(parts)<2 or parts[0]!=fa or '..' in parts or parts[1]=='test' or entry.is_dir(): continue
        dest = ASSETS.parent.joinpath(*parts)
        dest.parent.mkdir(parents=True, exist_ok=True)
        with z.open(entry) as src, dest.open('wb') as out: shutil.copyfileobj(src,out)
assert (ASSETS.parent/fa/'am/final.mdl').is_file()
print('Offline Persian recognition ready.', flush=True)
