package ir.example.persiancaller;
import android.Manifest;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.*;
import java.io.*;
import java.util.UUID;
public class MainActivity extends Activity {
    private String number = "", name = "آزمایش فارسی";
    private TextView status, selected;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) { number = state.getString("number", ""); name = state.getString("name", "آزمایش فارسی"); }
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(1); layout.setPadding(32, 32, 32, 32);
        ScrollView scroll = new ScrollView(this); scroll.addView(layout); setContentView(scroll);
        RingLevel.recoverIfInactive(this);
        Speaker.warm(this);
        ImageView brand = new ImageView(this); brand.setImageResource(R.drawable.mosavi); brand.setAdjustViewBounds(true); brand.setContentDescription("اختصاصی توسط موبایل موسوی"); layout.addView(brand, -1, -2);
        TextView title = new TextView(this); title.setText("گوینده فارسی تماس — نسخه " + installedVersion() + " (آزمایشی)\nاندروید ۱۰ به بالا؛ بدون مجوز اینترنت\nصدای فارسی داخلی هانیه — بدون نصب موتور جداگانه"); title.setTextSize(20); layout.addView(title);
        selected = new TextView(this); selected.setText(name + " " + number); layout.addView(selected);
        button(layout, "۱. اجازه خواندن مخاطبین", () -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, 10));
        button(layout, "اجازه وضعیت تلفن برای تکرار و توقف اعلان", () -> requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, 14));
        button(layout, "۲. فعال‌سازی شناسایی تماس", () -> {
            RoleManager rm = getSystemService(RoleManager.class);
            if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 11);
            else status.setText("این گوشی نقش شناسایی تماس را ارائه نمی‌کند.");
        });
        button(layout, "۳. انتخاب مخاطب برای آزمایش یا افزودن صدا", () -> {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) { status.setText("ابتدا اجازه مخاطبین را بدهید."); return; }
            startActivityForResult(new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI), 12);
        });
        button(layout, "۴. واردکردن فایل صوتی این مخاطب", () -> {
            if (number.isEmpty()) { status.setText("ابتدا مخاطب انتخاب کنید."); return; }
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("audio/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, 13);
        });
        button(layout, "آزمایش صدا", () -> Speaker.play(this, number, name + " تماس می‌گیرد", msg -> runOnUiThread(() -> status.setText(msg))));
        button(layout, "حذف صدای سفارشی مخاطب", () -> {
            String key = Contacts.key(number);
            String old = getSharedPreferences("audio", 0).getString(key, null);
            getSharedPreferences("audio", 0).edit().remove(key).apply();
            if (old != null) new File(getFilesDir(), old).delete();
            status.setText("صدای سفارشی حذف شد.");
        });
        status = new TextView(this); layout.addView(status);
    }
    private String installedVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (PackageManager.NameNotFoundException e) { return "نامشخص"; }
    }
    private void button(LinearLayout parent, String text, Runnable action) { Button b = new Button(this); b.setText(text); b.setOnClickListener(v -> action.run()); parent.addView(b); }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); out.putString("number", number); out.putString("name", name); }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (request == 12) {
                try (Cursor c = getContentResolver().query(uri, new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME}, null, null, null)) {
                    if (c != null && c.moveToFirst()) { number = c.getString(0); name = c.getString(1); selected.setText(name + " " + number); }
                }
            } else if (request == 13) {
                String filename = UUID.randomUUID().toString() + ".audio";
                File dest = new File(getFilesDir(), filename);
                try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(dest)) {
                    byte[] buffer = new byte[8192]; int n, total = 0;
                    while ((n = in.read(buffer)) != -1) { total += n; if (total > 10 * 1024 * 1024) throw new IOException("حداکثر حجم فایل ۱۰ مگابایت است"); out.write(buffer, 0, n); }
                } catch (Exception e) { dest.delete(); throw e; }
                String key = Contacts.key(number);
                String old = getSharedPreferences("audio", 0).getString(key, null);
                getSharedPreferences("audio", 0).edit().putString(key, filename).apply();
                if (old != null) new File(getFilesDir(), old).delete();
                status.setText("ذخیره شد؛ فایل کوتاه کمتر از ۱۵ ثانیه انتخاب کنید.");
            }
        } catch (Exception e) { status.setText("خطا: " + e.getMessage()); }
    }
}
