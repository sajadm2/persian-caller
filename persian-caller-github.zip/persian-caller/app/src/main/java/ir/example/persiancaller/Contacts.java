package ir.example.persiancaller;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.telephony.PhoneNumberUtils;
final class Contacts {
    static String key(String number) { return PhoneNumberUtils.normalizeNumber(number); }
    static String lookup(Context c, String number) {
        if (number == null || number.isEmpty()) return null;
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (SecurityException ignored) { }
        return null;
    }
}
