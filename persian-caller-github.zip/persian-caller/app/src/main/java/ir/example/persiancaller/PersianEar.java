package ir.example.persiancaller;

import android.content.Context;
import android.media.*;
import android.os.*;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.json.JSONObject;
import java.io.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** One utterance at a time. No network, audio files or transcript history. */
final class PersianEar {
    interface Events { void ready(); void result(String text); void error(String msg); }
    private static final String DIR="vosk-model-small-fa-0.42";
    private static Model shared;
    private static final AtomicBoolean busy=new AtomicBoolean();
    private volatile boolean cancelled;
    private final Handler ui=new Handler(Looper.getMainLooper());
    void stop(){cancelled=true;}
    void post(Runnable r){ui.post(()->{if(!cancelled)r.run();});}
    static void copy(Context c,String asset,File target)throws IOException{
        String[] children=c.getAssets().list(asset);
        if(children!=null && children.length>0){if(!target.isDirectory()&&!target.mkdirs())throw new IOException("mkdir");for(String child:children)copy(c,asset+"/"+child,new File(target,child));return;}
        try(InputStream in=c.getAssets().open(asset);OutputStream out=new FileOutputStream(target)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
    }
    static synchronized Model model(Context c)throws IOException{
        if(shared==null){File dir=new File(c.getNoBackupFilesDir(),DIR),marker=new File(dir,".complete");if(!marker.isFile()){copy(c,DIR,dir);if(!marker.createNewFile())throw new IOException("marker");}shared=new Model(dir.getPath());}return shared;
    }
    void start(Context ctx,boolean timed,Events e){Context c=ctx.getApplicationContext();new Thread(()->{
        if(!busy.compareAndSet(false,true)){post(()->e.error("شنیدن دیگری فعال است؛ اول آن را متوقف کن"));return;}
        AudioRecord mic=null;String text="",error=null,stage="آماده‌سازی مدل فارسی";
        try{Model m=model(c);if(cancelled)return;try(Recognizer rec=new Recognizer(m,16000f)){
            stage="دریافت صدا از میکروفون";int min=AudioRecord.getMinBufferSize(16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);if(min<=0)throw new IOException("PCM 16k");
            mic=new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(8192,min));mic.startRecording();if(mic.getRecordingState()!=AudioRecord.RECORDSTATE_RECORDING)throw new IOException("microphone");post(e::ready);
            short[] buf=new short[1600];long start=SystemClock.elapsedRealtime();while(!cancelled){int n=mic.read(buf,0,buf.length);if(n<=0)throw new IOException("read "+n);if(rec.acceptWaveForm(buf,n)){text=new JSONObject(rec.getResult()).optString("text").trim();if(!text.isEmpty())break;}if(timed&&SystemClock.elapsedRealtime()-start>=12000){text=new JSONObject(rec.getFinalResult()).optString("text").trim();break;}}
        }}catch(Exception|LinkageError ex){error=stage+": "+ex.getClass().getSimpleName();}finally{if(mic!=null){try{mic.stop();}catch(RuntimeException ignored){}mic.release();}busy.set(false);}
        final String msg=error,words=text;post(()->{if(msg!=null)e.error(msg);else e.result(words);});
    },"kara-fa-asr").start();}
}
