package ir.example.persiancaller;

final class SpokenNumber {
    static final String[] small="صفر یک دو سه چهار پنج شش هفت هشت نه ده یازده دوازده سیزده چهارده پانزده شانزده هفده هجده نوزده".split(" ");
    static final String[] tens="_ _ بیست سی چهل پنجاه شصت هفتاد هشتاد نود".split(" ");
    static final String[] hundreds="_ صد دویست سیصد چهارصد پانصد ششصد هفتصد هشتصد نهصد".split(" ");
    static String words(int n){if(n==32)return "سیُ دو";if(n==64)return "شَسْدُ چار";if(n<20)return small[n];int k=n<100?10:100;return (k==10?tens:hundreds)[n/k]+(n%k==0?"":" و "+words(n%k));}
    static String group(String g){return g.length()>1 && g.startsWith("0") ? "صفر "+group(g.substring(1)) : words(Integer.parseInt(g));}
    static String format(String raw){StringBuilder b=new StringBuilder(); if(raw!=null)for(char c:raw.toCharArray()){int d=Character.digit(c,10);if(d>=0)b.append(d);}
        String n=b.toString(); if(n.isEmpty())return "شماره ناشناس";
        if(n.matches("00989[0-9]{9}"))n=n.substring(4); else if(n.matches("989[0-9]{9}"))n=n.substring(2); else if(n.matches("09[0-9]{9}"))n=n.substring(1);
        if(n.matches("9[0-9]{9}"))return group(n.substring(0,3))+"، "+group(n.substring(3,6))+"، "+group(n.substring(6,8))+"، "+group(n.substring(8));
        b.setLength(0);for(char c:n.toCharArray()){if(b.length()>0)b.append(' ');b.append(small[c-'0']);}return b.toString();}
}
