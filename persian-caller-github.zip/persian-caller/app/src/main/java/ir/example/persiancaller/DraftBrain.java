package ir.example.persiancaller;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;
import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import java.io.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

/** Private, local draft generation; generated text is never executed as a command. */
final class DraftBrain {
    private final Activity a;
    private final TextView status;
    private final EditText question;
    private final File model;
    private static final ExecutorService worker=Executors.newSingleThreadExecutor();
    private static final AtomicBoolean busy=new AtomicBoolean();
    DraftBrain(Activity activity,LinearLayout box){
        a=activity; model=new File(a.getFilesDir(),"kara-model.task");
        Button choose=new Button(a);choose.setText("انتخاب مدل هوش مصنوعی (.task)");box.addView(choose);
        choose.setOnClickListener(v->a.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),82));
        question=new EditText(a);question.setHint("موضوع یا متن پیام را برای پیشنهاد جواب بنویس");box.addView(question);
        Button draft=new Button(a);draft.setText("پیشنهاد جواب با هوش مصنوعی آفلاین");box.addView(draft);
        status=new TextView(a);status.setTextIsSelectable(true);box.addView(status);status.setText(model.isFile()?"مدل وارد شده":"ابتدا مدل سازگار را انتخاب کن");
        draft.setOnClickListener(v->{String q=question.getText().toString().trim();if(q.isEmpty()||!model.isFile()){show("مدل و متن پیام لازم است");return;}if(q.length()>640){show("متن را کوتاه‌تر کن");return;}submit("در حال ساخت جواب…",()->{
            LlmInference.LlmInferenceOptions opts=LlmInference.LlmInferenceOptions.builder().setModelPath(model.getAbsolutePath()).setMaxTokens(1024).build();
            try(LlmInference engine=LlmInference.createFromOptions(a.getApplicationContext(),opts)){show(engine.generateResponse("یک جواب پیشنهادی کوتاه و طبیعی به فارسی بنویس. فقط متن پیشنهاد را بنویس. درخواست کاربر:\n"+q));}
        });});
    }
    void importModel(Uri uri){submit("در حال کپی مدل…",()->{
        File tmp=new File(model.getParentFile(),"kara-model.part");try{
            try(InputStream in=a.getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(tmp)){if(in==null)throw new IOException();byte[] buf=new byte[262144];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}
            if(tmp.length()==0||!tmp.renameTo(model))throw new IOException();show("مدل کپی شد؛ حالا یک جواب پیشنهادی آزمایش کن.");
        }finally{tmp.delete();}
    });}
    interface Job{void run() throws Exception;}
    private void submit(String msg,Job j){if(!busy.compareAndSet(false,true)){show("لطفاً تا پایان عملیات صبر کن");return;}show(msg);worker.execute(()->{try{j.run();}catch(Exception|LinkageError|OutOfMemoryError e){show("اجرا نشد؛ مدل سازگار، فضای خالی و حافظهٔ آزاد را بررسی کن. "+e.getClass().getSimpleName());}finally{busy.set(false);}});}
    private void show(String s){a.runOnUiThread(()->{if(!a.isDestroyed())status.setText(s);});}
}
