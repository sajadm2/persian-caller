package ir.example.persiancaller;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;

// Main thread only. Journal the original setting before changing shared system volume.
final class RingLevel {
    static Context active;
    static void lower(Context c){
        recoverIfInactive(c);
        if(active!=null)return;
        AudioManager a=c.getSystemService(AudioManager.class); int s=AudioManager.STREAM_RING;
        SharedPreferences p=c.getSharedPreferences("ringRecovery",0);
        try {if(p.contains("old") || a.isVolumeFixed() || a.getRingerMode()!=AudioManager.RINGER_MODE_NORMAL)return;
            int old=a.getStreamVolume(s), target=Math.max(1,Math.round(a.getStreamMaxVolume(s)*0.2f));
            if(old<=target || !p.edit().putInt("old",old).putInt("target",target).commit())return;
            active=c.getApplicationContext(); a.setStreamVolume(s,target,0);
        }catch(RuntimeException ignored){end();}
    }
    static void end(){if(active!=null){Context c=active;active=null;recoverIfInactive(c);}}
    static void recoverIfInactive(Context c){if(active!=null)return;
        SharedPreferences p=c.getSharedPreferences("ringRecovery",0); if(!p.contains("old"))return;
        AudioManager a=c.getSystemService(AudioManager.class); int s=AudioManager.STREAM_RING;
        try{if(a.getRingerMode()==AudioManager.RINGER_MODE_NORMAL && a.getStreamVolume(s)==p.getInt("target",-1))a.setStreamVolume(s,p.getInt("old",1),0);
            p.edit().clear().commit();}catch(RuntimeException ignored){}
    }
}
