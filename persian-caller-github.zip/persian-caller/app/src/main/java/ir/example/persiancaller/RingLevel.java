package ir.example.persiancaller;
import android.content.*;
import android.media.AudioManager;
import android.os.*;

// Main-thread only. Never restore over an observed user volume change.
final class RingLevel {
    static final Handler h=new Handler(Looper.getMainLooper());
    static final int RING=AudioManager.STREAM_RING;
    static Context active; static int epoch,original,last; static boolean restoring;
    static SharedPreferences journal(Context c){return c.getSharedPreferences("ringRecovery",0);}
    static void clear(){epoch++; if(active!=null)journal(active).edit().clear().commit();active=null;restoring=false;}
    static void lower(Context c){
        recoverIfInactive(c); AudioManager a=c.getSystemService(AudioManager.class);
        if(active==null){if(journal(c).contains("old")||a.isVolumeFixed()||a.getRingerMode()!=AudioManager.RINGER_MODE_NORMAL)return;
            original=last=a.getStreamVolume(RING);if(original<=1)return;active=c.getApplicationContext();}
        restoring=false;ramp(++epoch,last,Math.max(1,Math.round(original*.2f)),1);
    }
    static void end(){if(active!=null&&!restoring){restoring=true;ramp(++epoch,last,original,1);}}
    static void ramp(int id,int from,int to,int i){if(id!=epoch||active==null)return;
        AudioManager a=active.getSystemService(AudioManager.class);try{
            if(a.getRingerMode()!=AudioManager.RINGER_MODE_NORMAL||a.getStreamVolume(RING)!=last){clear();return;}
            int next=Math.round(from+(to-from)*i/5f);
            if(next!=last){if(!journal(active).edit().putInt("old",original).putInt("target",next).putInt("previous",last).commit())throw new IllegalStateException();a.setStreamVolume(RING,next,0);last=next;}
            if(i<5)h.postDelayed(()->ramp(id,from,to,i+1),45);else if(restoring)clear();
        }catch(RuntimeException ex){Context c=active;epoch++;active=null;restoring=false;recoverIfInactive(c);}}
    static void recoverIfInactive(Context c){if(active!=null)return; SharedPreferences p=journal(c);if(!p.contains("old"))return;
        AudioManager a=c.getSystemService(AudioManager.class);try{int v=a.getStreamVolume(RING);if(a.getRingerMode()==AudioManager.RINGER_MODE_NORMAL&&(v==p.getInt("target",-1)||v==p.getInt("previous",-1)))a.setStreamVolume(RING,p.getInt("old",v),0);p.edit().clear().commit();}catch(RuntimeException ignored){} }
}
