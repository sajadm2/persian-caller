package ir.example.persiancaller;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import java.io.File;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

final class Speaker {
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static MediaPlayer player;
    private static AudioManager manager;
    private static AudioFocusRequest focus;
    private static volatile int generation;
    interface Result { void show(String message); }

    static void play(Context c, String number, String text, Result result) {
        begin(c, number, text, result, false);
    }
    static void announceCall(Context c, String number, String text, Result result) {
        begin(c, number, text, result, true);
    }
    private static void begin(Context context, String number, String text, Result result, boolean call) {
        Context c = context.getApplicationContext();
        handler.post(() -> {
            finish();
            final int token = generation;
            boolean monitor = call && c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
            if (!audible(c)) { result.show("گوشی در حالت بی‌صدا یا لرزش است."); return; }
            result.show(monitor ? "آماده‌سازی اعلان تکرارشونده…" : "آماده‌سازی صدا؛ بدون مجوز وضعیت تلفن فقط یک‌بار پخش می‌شود.");
            // A hard bound also protects against missed phone-state changes.
            handler.postDelayed(() -> { if (generation == token) finish(); }, call ? 60000 : 30000);
            if (monitor) watchCall(c, token, SystemClock.elapsedRealtime(), false);
            worker.execute(() -> {
                if (generation != token) return;
                try {
                    String saved = c.getSharedPreferences("audio", 0).getString(Contacts.key(number), null);
                    File audio = saved == null ? null : new File(c.getFilesDir(), saved);
                    if (audio == null || !audio.isFile()) audio = EmbeddedVoice.render(c, text);
                    File ready = audio;
                    handler.post(() -> playFile(c, ready, token, monitor, result));
                } catch (Exception | LinkageError e) {
                    handler.post(() -> { if (generation == token) { finish(); result.show("خطای موتور: " + e.getMessage()); } });
                }
            });
        });
    }
    @SuppressWarnings("deprecation")
    private static void watchCall(Context c, int token, long started, boolean seenRinging) {
        if (generation != token) return;
        try {
            int state = c.getSystemService(TelephonyManager.class).getCallState();
            boolean ringing = state == TelephonyManager.CALL_STATE_RINGING;
            if (state == TelephonyManager.CALL_STATE_OFFHOOK ||
                (state == TelephonyManager.CALL_STATE_IDLE && (seenRinging || SystemClock.elapsedRealtime() - started > 5000))) {
                finish(); return;
            }
            handler.postDelayed(() -> watchCall(c, token, started, seenRinging || ringing), 300);
        } catch (SecurityException e) { finish(); }
    }
    private static void playFile(Context c, File audio, int token, boolean repeat, Result result) {
        if (generation != token) return;
        if (!audible(c)) { finish(); return; }
        try {
            releasePlayback();
            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
            manager = c.getSystemService(AudioManager.class);
            focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attributes)
                .setOnAudioFocusChangeListener(change -> {
                    if (generation == token && (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT)) finish();
                }, handler).build();
            int granted = manager.requestAudioFocus(focus);
            player = new MediaPlayer();
            MediaPlayer current = player;
            player.setAudioAttributes(attributes);
            player.setVolume(1f, 1f);
            player.setDataSource(audio.getPath());
            player.setOnCompletionListener(p -> {
                if (generation != token || player != p) return;
                releasePlayback();
                if (repeat) handler.postDelayed(() -> playFile(c, audio, token, true, result), 4000);
                else finish();
            });
            player.setOnErrorListener((p, a, b) -> {
                if (generation == token) { finish(); result.show("خطا در پخش صدا"); }
                return true;
            });
            player.setOnPreparedListener(p -> {
                if (generation != token || player != p) return;
                p.start();
                result.show(granted == AudioManager.AUDIOFOCUS_REQUEST_GRANTED ? "پخش اعلان فارسی" : "پخش اعلان؛ اولویت صدا توسط سیستم پذیرفته نشد");
                handler.postDelayed(() -> { if (generation == token && player == current) finish(); }, 15000);
            });
            player.prepareAsync();
        } catch (Exception e) { finish(); result.show("خطای پخش: " + e.getMessage()); }
    }
    private static boolean audible(Context c) {
        return c.getSystemService(AudioManager.class).getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
    }
    private static void releasePlayback() {
        if (player != null) { player.release(); player = null; }
        if (manager != null && focus != null) manager.abandonAudioFocusRequest(focus);
        focus = null;
    }
    private static void finish() { generation++; releasePlayback(); }
}
