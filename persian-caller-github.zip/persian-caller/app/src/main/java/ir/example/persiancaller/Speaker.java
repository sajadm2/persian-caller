package ir.example.persiancaller;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

final class Speaker {
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static MediaPlayer player;
    private static volatile int generation;
    interface Result { void show(String message); }

    static void play(Context context, String number, String text, Result result) {
        Context c = context.getApplicationContext();
        handler.post(() -> {
            stop();
            final int token = ++generation;
            if (!audible(c)) { result.show("گوشی در حالت بی‌صدا یا لرزش است."); return; }
            result.show("آماده‌سازی صدای فارسی داخلی؛ بار اول ممکن است طول بکشد…");
            // Discard delayed results; a telecom callback must never wait for synthesis.
            handler.postDelayed(() -> {
                if (generation == token) { generation++; stop(); }
            }, 30000);
            worker.execute(() -> {
                if (generation != token) return;
                try {
                    String saved = c.getSharedPreferences("audio", 0).getString(Contacts.key(number), null);
                    File audio = saved == null ? null : new File(c.getFilesDir(), saved);
                    if (audio == null || !audio.isFile()) audio = EmbeddedVoice.render(c, text);
                    File ready = audio;
                    handler.post(() -> {
                        if (generation != token || !audible(c)) return;
                        try {
                            player = new MediaPlayer();
                            player.setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                            player.setDataSource(ready.getPath());
                            player.setOnCompletionListener(p -> { if (generation == token) stop(); });
                            player.setOnErrorListener((p,a,b) -> {
                                if (generation == token) stop();
                                result.show("خطا در پخش صدا"); return true;
                            });
                            player.setOnPreparedListener(p -> {
                                if (generation != token) return;
                                p.start(); result.show("پخش صدای فارسی آفلاین");
                                handler.postDelayed(() -> { if (generation == token) stop(); }, 15000);
                            });
                            player.prepareAsync();
                        } catch (Exception e) { stop(); result.show("خطا در پخش: " + e.getMessage()); }
                    });
                } catch (Exception | LinkageError e) {
                    handler.post(() -> { if (generation == token) result.show("خطای موتور داخلی: " + e.getMessage()); });
                }
            });
        });
    }
    private static boolean audible(Context c) {
        return ((AudioManager)c.getSystemService(Context.AUDIO_SERVICE)).getRingerMode() == AudioManager.RINGER_MODE_NORMAL;
    }
    private static void stop() {
        if (player != null) { player.release(); player = null; }
    }
}
