package ir.example.persiancaller;
import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;

public class ContinueActivity extends Activity {
 @Override protected void onCreate(Bundle b){super.onCreate(b); long t=getIntent().getLongExtra("until",0); if(t<SystemClock.elapsedRealtime()||t>SystemClock.elapsedRealtime()+60000){finish();return;}KeyguardManager km=getSystemService(KeyguardManager.class);if(km.isDeviceLocked()){setShowWhenLocked(true);km.requestDismissKeyguard(this,new KeyguardManager.KeyguardDismissCallback(){public void onDismissSucceeded(){open(t);} public void onDismissCancelled(){finish();} public void onDismissError(){finish();}});}else open(t);}
 void open(long t){if(t>=SystemClock.elapsedRealtime()&&!getSystemService(KeyguardManager.class).isDeviceLocked())startActivity(new Intent(Settings.ACTION_SETTINGS));finish();}
}
