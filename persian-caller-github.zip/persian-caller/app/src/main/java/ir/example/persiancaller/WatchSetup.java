package ir.example.persiancaller;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.util.Base64;
import android.widget.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.PBEKeySpec;

final class WatchSetup {
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("kara-private",0);}
 static String digits(String s){StringBuilder b=new StringBuilder(); for(String w:s.trim().split("[\\s،,]+")){int i=java.util.Arrays.asList(SpokenNumber.small).indexOf(w);if(i>=0&&i<10)b.append(i);else for(char ch:w.toCharArray()){int n=Character.digit(ch,10);if(n<0)return "";b.append(n);}}return b.toString();}
 static byte[] hash(String pin,byte[] salt)throws Exception {PBEKeySpec k=new PBEKeySpec(pin.toCharArray(),salt,65000,256);try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(k).getEncoded();}finally{k.clearPassword();}}
 static boolean match(Context c,String s){try{String pin=digits(s);if(!pin.matches("[0-9]{4,8}"))return false;return MessageDigest.isEqual(Base64.decode(prefs(c).getString("hash",""),0),hash(pin,Base64.decode(prefs(c).getString("salt",""),0)));}catch(Exception e){return false;}}
 static void toast(Activity a,String s){Toast.makeText(a,s,Toast.LENGTH_LONG).show();}
 static void add(Activity a,LinearLayout l){Button p=new Button(a);p.setText("تعیین رمز مخصوص کارا");l.addView(p);p.setOnClickListener(v->{EditText t=new EditText(a);t.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);new AlertDialog.Builder(a).setTitle("۴ تا ۸ رقم؛ رمز قفل گوشی نباشد").setView(t).setNegativeButton("لغو",null).setPositiveButton("ذخیره",(d,i)->{String pin=digits(t.getText().toString());if(!pin.matches("[0-9]{4,8}")){toast(a,"۴ تا ۸ رقم وارد کن");return;}try{byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);prefs(a).edit().putString("salt",Base64.encodeToString(salt,2)).putString("hash",Base64.encodeToString(hash(pin,salt),2)).apply();toast(a,"رمز کارا ذخیره شد");}catch(Exception ex){toast(a,"ذخیره نشد");}}).show();});
 Button start=new Button(a);l.addView(start);start.setText("روشن کردن گوش‌به‌زنگ کارا");start.setOnClickListener(v->{if(!prefs(a).contains("hash")){toast(a,"اول رمز کارا را تعیین کن");return;}if(Build.VERSION.SDK_INT<31||!SpeechRecognizer.isOnDeviceRecognitionAvailable(a)){toast(a,"تشخیص گفتار روی دستگاه در دسترس نیست");return;}java.util.ArrayList<String> missing=new java.util.ArrayList<>(); for(String perm:new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.POST_NOTIFICATIONS}){if(perm.equals(Manifest.permission.POST_NOTIFICATIONS)&&Build.VERSION.SDK_INT<33)continue;if(a.checkSelfPermission(perm)!=PackageManager.PERMISSION_GRANTED)missing.add(perm);}if(!missing.isEmpty()){toast(a,"بعد از دادن مجوز، دوباره روشن کردن را بزن");a.requestPermissions(missing.toArray(new String[0]),42);return;}try{a.startForegroundService(new Intent(a,WatchService.class));}catch(RuntimeException e){toast(a,"شروع سرویس ممکن نشد");}});
 Button stop=new Button(a);stop.setText("توقف گوش‌به‌زنگ");l.addView(stop);stop.setOnClickListener(v->a.stopService(new Intent(a,WatchService.class)));}
}
