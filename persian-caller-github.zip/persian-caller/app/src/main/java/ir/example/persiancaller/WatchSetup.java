package ir.example.persiancaller;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.util.Base64;
import android.widget.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.PBEKeySpec;

final class WatchSetup {
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("kara-private",0);}
 static void toast(Activity a,String s){Toast.makeText(a,s,Toast.LENGTH_LONG).show();}
 static void add(Activity a,LinearLayout l){
 Button start=new Button(a);l.addView(start);start.setText("روشن کردن گوش‌به‌زنگ کارا");start.setOnClickListener(v->{java.util.ArrayList<String> missing=new java.util.ArrayList<>(); for(String perm:new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.POST_NOTIFICATIONS}){if(perm.equals(Manifest.permission.POST_NOTIFICATIONS)&&Build.VERSION.SDK_INT<33)continue;if(a.checkSelfPermission(perm)!=PackageManager.PERMISSION_GRANTED)missing.add(perm);}if(!missing.isEmpty()){toast(a,"بعد از دادن مجوز، دوباره روشن کردن را بزن");a.requestPermissions(missing.toArray(new String[0]),42);return;}try{a.startForegroundService(new Intent(a,WatchService.class));}catch(RuntimeException e){toast(a,"شروع سرویس ممکن نشد");}});
 Button diagnostic=new Button(a);diagnostic.setText("وضعیت شنیدن کارا");l.addView(diagnostic);diagnostic.setOnClickListener(v->new AlertDialog.Builder(a).setTitle("آخرین وضعیت شنیدن").setMessage(prefs(a).getString("earStatus","هنوز گزارشی از گوش‌به‌زنگ ثبت نشده")).setPositiveButton("باشه",null).show());
 Button calls=new Button(a);calls.setText("مجوز فرمان‌های تماس کارا");l.addView(calls);calls.setOnClickListener(v->a.requestPermissions(new String[]{Manifest.permission.ANSWER_PHONE_CALLS,Manifest.permission.READ_PHONE_STATE},43));
 Button stop=new Button(a);stop.setText("توقف گوش‌به‌زنگ");l.addView(stop);stop.setOnClickListener(v->a.stopService(new Intent(a,WatchService.class)));}
}
