package ir.example.persiancaller;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.*;
import android.widget.*;
import java.util.ArrayList;

/** Push-to-talk only. Never switches to an online recognizer. */
final class Kara {
    final Activity a; final EditText input; final TextView note; PersianEar ear;
    Kara(Activity a, LinearLayout box) {
        this.a=a; Button mic=new Button(a); mic.setText("🎙 صحبت با کارا"); box.addView(mic); mic.setOnClickListener(v->listen());
        input=new EditText(a); input.setSingleLine(true); input.setHint("کارا تنظیمات رو باز کن"); box.addView(input);
        Button run=new Button(a); run.setText("اجرای دستور نوشته‌شده"); box.addView(run); run.setOnClickListener(v->execute(input.getText().toString()));
        note=new TextView(a); box.addView(note);
        Button sms=new Button(a);sms.setText("نوشتن پیامک");box.addView(sms);sms.setOnClickListener(v->composeSms());
    }
    static String smsNumber(String raw){StringBuilder out=new StringBuilder();for(char c:raw.toCharArray()){int d=Character.digit(c,10);if(d>=0)out.append(d);else if(" ()-".indexOf(c)<0)out.append(c);}return out.toString();}
    void composeSms(){
        close();
        LinearLayout panel=new LinearLayout(a);panel.setOrientation(1);panel.setPadding(32,8,32,8);
        EditText to=new EditText(a);to.setSingleLine(true);to.setInputType(android.text.InputType.TYPE_CLASS_PHONE);to.setHint("شمارهٔ یک گیرنده");panel.addView(to);
        EditText body=new EditText(a);body.setHint("متن پیامک");body.setMinLines(2);panel.addView(body);
        TextView hint=new TextView(a);Button dictate=new Button(a);dictate.setText("گفتن متن پیامک");panel.addView(dictate);panel.addView(hint);
        android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(a).setTitle("پیامک جدید").setView(panel).setNegativeButton("لغو",null).setPositiveButton("بازبینی در پیام‌رسان",null).create();
        dictate.setOnClickListener(v->{if(a.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){a.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},41);return;}close();dictate.setEnabled(false);hint.setText("در حال آماده‌سازی…");ear=new PersianEar();ear.start(a,true,new PersianEar.Events(){public void ready(){hint.setText("حالا متن پیام را بگو");}public void result(String text){dictate.setEnabled(true);if(text.isEmpty()){hint.setText("متنی شنیده نشد؛ دوباره بگو یا تایپ کن");return;}if(body.length()>0)body.append(" ");body.append(text);hint.setText("می‌توانی متن را ویرایش کنی یا ادامه‌اش را بگویی");}public void error(String msg){dictate.setEnabled(true);hint.setText(msg);}});});
        dialog.setOnDismissListener(d->close());dialog.show();dialog.getButton(-1).setOnClickListener(v->{String num=smsNumber(to.getText().toString());if(!num.matches("\\+?[0-9]{3,15}")){to.setError("شمارهٔ گیرنده را بررسی کن");return;}String text=body.getText().toString().trim();if(text.isEmpty()){body.setError("متن پیام خالی است");return;}try{a.startActivity(new Intent(Intent.ACTION_SENDTO,Uri.fromParts("smsto",num,null)).putExtra("sms_body",text));dialog.dismiss();}catch(android.content.ActivityNotFoundException ex){hint.setText("برنامه‌ای برای ارسال پیامک پیدا نشد");}});
    }
    void listen(){
        close();
        if(a.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){a.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},41);return;}
        note.setText("در حال آماده‌سازی مدل فارسی داخلی");ear=new PersianEar();ear.start(a,true,new PersianEar.Events(){public void ready(){note.setText("حالا دستور را بگو…");}public void result(String text){if(text.isEmpty()){fallback();return;}input.setText(text);execute(text);}public void error(String msg){note.setText(msg);}});
    }
    void close(){if(ear!=null)ear.stop();ear=null;}
    void fallback(){note.setText("فرمان صوتی دریافت نشد. دوباره تلاش کن یا دستور را تایپ کن.");}
    void execute(String raw){
        String s=raw.replace('ي','ی').replace('ك','ک').replace('\u200c',' ').replaceAll("[،,.؟!?]"," ").trim().replaceFirst("(?i)^(کارا|kara)\\s+","").replaceAll("\\s+"," ");
        try{
            if(s.matches("(پیامک|پیامک جدید|پیامک بنویس|پیام بنویس)")){composeSms();return;}
            if(s.matches("تنظیمات(?: گوشی)?(?: ر[او])? باز کن")){note.setText("باز کردن تنظیمات");a.startActivity(new Intent(Settings.ACTION_SETTINGS));return;}
            if(s.endsWith(" بگیر")){
                String body=s.replaceFirst("^شماره\\s+","").replaceFirst("(?: ر[او])? بگیر$","");
                StringBuilder n=new StringBuilder();for(String token:body.split(" ")){int index=java.util.Arrays.asList(SpokenNumber.small).indexOf(token);if(index>=0&&index<10)n.append(index);else for(char c:token.toCharArray()){int d=Character.digit(c,10);if(d>=0)n.append(d);else if(c=='+'&&n.length()==0)n.append(c);else if(c!='-'){note.setText("شماره را رقم‌به‌رقم بگو یا بنویس.");return;}}}
                if(n.toString().matches("\\+?[0-9]{3,15}")){note.setText("شماره را پیش از تماس بررسی کن.");a.startActivity(new Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",n.toString(),null)));return;}
            }
            note.setText("مثال: کارا تنظیمات رو باز کن / کارا ۰۹۱۶۹۸۰۳۲۶۴ رو بگیر");
        }catch(RuntimeException e){note.setText("این فرمان روی گوشی اجرا نشد.");}
    }
}
