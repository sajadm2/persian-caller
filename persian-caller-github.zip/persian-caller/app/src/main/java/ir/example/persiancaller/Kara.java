package ir.example.persiancaller;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.*;
import android.widget.*;
import java.util.ArrayList;

/** Push-to-talk only. Never switches to an online recognizer. */
final class Kara {
    final Activity a; final EditText input; final TextView note; PersianEar ear;
    Kara(Activity a, LinearLayout box) {
        this.a=a; Button mic=new Button(a); mic.setText("🎙 صحبت با کارا"); box.addView(mic); mic.setOnClickListener(v->listen());
        input=new EditText(a); input.setSingleLine(true); input.setHint("کارا تنظیمات رو باز کن"); box.addView(input);
        Button run=new Button(a); run.setText("اجرای دستور نوشته‌شده"); box.addView(run); run.setOnClickListener(v->execute(input.getText().toString()));
        note=new TextView(a); box.addView(note);
    }
    void listen(){
        close();
        if(a.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){a.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},41);return;}
        note.setText("در حال آماده‌سازی مدل فارسی داخلی");ear=new PersianEar();ear.start(a,true,new PersianEar.Events(){public void ready(){note.setText("حالا دستور را بگو…");}public void result(String text){if(text.isEmpty()){fallback();return;}input.setText(text);execute(text);}public void error(String msg){note.setText(msg);}});
    }
    void close(){if(ear!=null)ear.stop();ear=null;}
    void fallback(){note.setText("فرمان صوتی دریافت نشد. دوباره تلاش کن یا دستور را تایپ کن.");}
    void execute(String raw){
        String s=raw.replace('ي','ی').replace('ك','ک').replace('\u200c',' ').replaceAll("[،,.؟!?]"," ").trim().replaceFirst("(?i)^(کارا|kara)\\s+","").replaceAll("\\s+"," ");
        try{
            if(s.matches("تنظیمات(?: گوشی)?(?: ر[او])? باز کن")){note.setText("باز کردن تنظیمات");a.startActivity(new Intent(Settings.ACTION_SETTINGS));return;}
            if(s.endsWith(" بگیر")){
                String body=s.replaceFirst("^شماره\\s+","").replaceFirst("(?: ر[او])? بگیر$","");
                StringBuilder n=new StringBuilder();for(String token:body.split(" ")){int index=java.util.Arrays.asList(SpokenNumber.small).indexOf(token);if(index>=0&&index<10)n.append(index);else for(char c:token.toCharArray()){int d=Character.digit(c,10);if(d>=0)n.append(d);else if(c=='+'&&n.length()==0)n.append(c);else if(c!='-'){note.setText("شماره را رقم‌به‌رقم بگو یا بنویس.");return;}}}
                if(n.toString().matches("\\+?[0-9]{3,15}")){note.setText("شماره را پیش از تماس بررسی کن.");a.startActivity(new Intent(Intent.ACTION_DIAL,Uri.fromParts("tel",n.toString(),null)));return;}
            }
            note.setText("مثال: کارا تنظیمات رو باز کن / کارا ۰۹۱۶۹۸۰۳۲۶۴ رو بگیر");
        }catch(RuntimeException e){note.setText("این فرمان روی گوشی اجرا نشد.");}
    }
}
