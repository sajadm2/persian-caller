package ir.example.persiancaller

import android.content.Context
import com.k2fsa.sherpa.onnx.*
import java.io.File
import java.security.MessageDigest

/** Called only by Speaker's serial worker, not the UI or telecom callback. */
object EmbeddedVoice {
    private var engine: OfflineTts? = null

    private fun copyAsset(context: Context, asset: String, target: File) {
        val children = context.assets.list(asset) ?: emptyArray()
        if (children.isNotEmpty()) {
            target.mkdirs()
            for (child in children) copyAsset(context, "$asset/$child", File(target, child))
        } else {
            target.parentFile?.mkdirs()
            context.assets.open(asset).use { input -> target.outputStream().use { input.copyTo(it) } }
        }
    }

    @JvmStatic
    @Synchronized
    fun warm(context: Context) {
        if (engine != null) return
        val dir = File(context.filesDir, "voice-haaniye-v1")
        val marker = File(dir, ".ready")
        if (!marker.exists()) {
            dir.deleteRecursively()
            copyAsset(context, "voice", dir)
            marker.writeText("1")
        }
        engine = OfflineTts(config = OfflineTtsConfig(model = OfflineTtsModelConfig(
            vits = OfflineTtsVitsModelConfig(model = File(dir, "fa-haaniye_low.onnx").path,
                tokens = File(dir, "tokens.txt").path, dataDir = File(dir, "espeak-ng-data").path),
            numThreads = 2, debug = false, provider = "cpu")))
    }

    @JvmStatic
    @Synchronized
    fun render(context: Context, text: String): File {
        val key = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        val cache = File(context.cacheDir, "speech-v1").apply { mkdirs() }
        val output = File(cache, "$key.wav")
        if (output.exists() && output.length() > 44) return output
        warm(context)
        // Bound the disposable speech cache to roughly 50 MB.
        val old = cache.listFiles()?.sortedBy { it.lastModified() } ?: emptyList()
        var total = old.sumOf { it.length() }
        for (file in old) {
            if (total <= 50L * 1024 * 1024) break
            total -= file.length(); file.delete()
        }
        val temporary = File(cache, "$key.tmp.wav")
        check(engine!!.generate(text.take(180), sid = 0, speed = 1.0f).save(temporary.path)) {
            "ذخیره صدای فارسی ناموفق بود"
        }
        check(temporary.renameTo(output)) { "خطای ذخیره فایل صوتی" }
        return output
    }
}
