package ir.example.persiancaller;
import android.app.*;
import android.content.*;
import android.os.*;
import android.media.MediaPlayer;
import android.speech.*;
import android.widget.Toast;
import java.util.*;
import java.io.File;
import java.util.concurrent.*;

/** Experimental foreground, on-device recognition sessions. Never starts at boot. */
public class WatchService extends Service {
 final Handler h=new Handler(Looper.getMainLooper()); final ExecutorService worker=Executors.newSingleThreadExecutor();
 PersianEar ear; MediaPlayer voice; boolean running; int errors; String pending=""; long until;
 static final String CHANNEL="kara-watch"; final Runnable expire=()->{pending="";until=0;};
 public IBinder onBind(Intent i){return null;}
 Notification notification(String text, PendingIntent open){PendingIntent stop=PendingIntent.getService(this,9,new Intent(this,WatchService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("کارا • گوش‌به‌زنگ").setContentText(text).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open).addAction(android.R.drawable.ic_delete,"توقف",stop).build();}
 void note(String s,PendingIntent p){getSystemService(NotificationManager.class).notify(51,notification(s,p));}
 public int onStartCommand(Intent i,int flags,int id){if(i!=null&&"stop".equals(i.getAction())){running=false;stopSelf();return START_NOT_STICKY;}if(running)return START_NOT_STICKY;
 getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL,"گوش‌به‌زنگ کارا",NotificationManager.IMPORTANCE_LOW));
 startForeground(51,notification("گوش می‌دهم؛ بگو کارا ساعت چنده",null));running=true;listen();return START_NOT_STICKY;}
 void drop(){if(ear!=null)ear.stop();ear=null;}
 void later(long ms){if(running)h.postDelayed(this::listen,ms);}
 void status(String s){WatchSetup.prefs(this).edit().putString("earStatus",s).apply();}
 void fail(String reason){status(reason);Toast.makeText(this,reason,Toast.LENGTH_LONG).show();running=false;stopSelf();}
 void listen(){if(!running)return;drop();status("در حال آماده‌سازی مدل فارسی داخلی");ear=new PersianEar();ear.start(this,false,new PersianEar.Events(){public void ready(){if(running)status("مدل فارسی داخلی آمادهٔ شنیدن است");}public void result(String text){if(running)heard(text);}public void error(String msg){if(running)fail(msg);}});}
 void heard(String raw){status("گفتار دریافت شد");String s=raw.replace('ي','ی').replace('ك','ک').replaceAll("[،؟!.,‌]"," ").trim().replaceAll("\\s+"," ");long now=SystemClock.elapsedRealtime();SharedPreferences p=WatchSetup.prefs(this);
 if(System.currentTimeMillis()<p.getLong("blocked",0)){later(700);return;}
 if(!pending.isEmpty()&&now<until){String cmd=pending;expire.run();h.removeCallbacks(expire);
 if(!WatchSetup.match(this,s)){int tries=p.getInt("tries",0)+1;p.edit().putInt("tries",tries%3).putLong("blocked",tries>=3?System.currentTimeMillis()+60000:0).apply();say("رمز درست نیست",()->later(500));return;}
 p.edit().remove("tries").apply();if(cmd.equals("time")){Calendar c=Calendar.getInstance();say("درسته، ساعت "+SpokenNumber.words(c.get(Calendar.HOUR_OF_DAY))+" و "+SpokenNumber.words(c.get(Calendar.MINUTE))+" دقیقه است",()->later(500));}
 else {PendingIntent open=PendingIntent.getActivity(this,10,new Intent(this,ContinueActivity.class).putExtra("until",now+60000),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_ONE_SHOT|PendingIntent.FLAG_IMMUTABLE);note("برای باز کردن تنظیمات لمس کن",open);say("درسته، برای تنظیمات اعلان کارا را لمس کن",()->later(500));}return;}
 if(callCommand(s)){later(350);return;}
 if(s.matches("کارا ساعت (چنده|چند است|چندِه)"))pending="time";else if(s.matches("کارا تنظیمات(?: ر[او])? باز کن"))pending="settings";else{later(350);return;}
 say("رمز کارا رو بگو",()->{until=SystemClock.elapsedRealtime()+16000;h.removeCallbacks(expire);h.postDelayed(expire,16000);later(180);});}
 @SuppressWarnings("deprecation") boolean callCommand(String s){
 boolean answer=s.matches("کارا تماس (رو|را) وصل کن"),end=s.matches("کارا تماس (رو|را) قطع کن"),speaker=s.equals("کارا بزن روی بلندگو");
 if(!answer&&!end&&!speaker)return false;
 try{if(checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new SecurityException();
 int state=getSystemService(android.telephony.TelephonyManager.class).getCallState();boolean ring=state==android.telephony.TelephonyManager.CALL_STATE_RINGING,active=state==android.telephony.TelephonyManager.CALL_STATE_OFFHOOK;
 android.telecom.TelecomManager tel=getSystemService(android.telecom.TelecomManager.class);
 if(answer&&ring)tel.acceptRingingCall();else if(end&&(active||ring)){if(!tel.endCall())note("سیستم تماس را قطع نکرد",null);}else if(speaker&&active&&Build.VERSION.SDK_INT>=31){android.media.AudioManager audio=getSystemService(android.media.AudioManager.class);boolean ok=false;for(android.media.AudioDeviceInfo d:audio.getAvailableCommunicationDevices())if(d.getType()==android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER){ok=audio.setCommunicationDevice(d);break;}if(ok){routed=true;h.removeCallbacks(routeCheck);h.postDelayed(routeCheck,500);}else note("تغییر مسیر صدای تماس پذیرفته نشد",null);}
 }catch(RuntimeException e){note("فرمان اجرا نشد؛ مجوز یا دسترسی کنترل تماس در دسترس نیست",null);}return true;}
 boolean routed;void clearRoute(){if(routed){routed=false;try{getSystemService(android.media.AudioManager.class).clearCommunicationDevice();}catch(RuntimeException ignored){}}}
 final Runnable routeCheck=new Runnable(){public void run(){try{if(getSystemService(android.telephony.TelephonyManager.class).getCallState()==android.telephony.TelephonyManager.CALL_STATE_OFFHOOK){h.postDelayed(this,500);return;}}catch(RuntimeException ignored){}clearRoute();}};
 void say(String text,Runnable done){worker.execute(()->{try{File file=EmbeddedVoice.render(this,text);h.post(()->{if(!running)return;try{voice=new MediaPlayer();voice.setDataSource(file.getPath());voice.setOnCompletionListener(p->{release();done.run();});voice.setOnErrorListener((p,a,b)->{release();fail("خطا در پخش پاسخ کارا ("+a+", "+b+")");return true;});voice.prepare();voice.start();}catch(Exception ex){release();fail("پخش پاسخ کارا شروع نشد: "+ex.getClass().getSimpleName());}});}catch(Exception|LinkageError e){h.post(()->{if(running)fail("ساخت صدای پاسخ کارا ممکن نشد: "+e.getClass().getSimpleName());});}});}
 void release(){if(voice!=null){voice.release();voice=null;}}
 public void onDestroy(){clearRoute();running=false;h.removeCallbacksAndMessages(null);drop();release();worker.shutdownNow();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
