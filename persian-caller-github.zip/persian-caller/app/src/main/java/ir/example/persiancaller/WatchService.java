package ir.example.persiancaller;
import android.app.*;
import android.content.*;
import android.os.*;
import android.media.MediaPlayer;
import android.speech.*;
import android.widget.Toast;
import java.util.*;
import java.io.File;
import java.util.concurrent.*;

/** Experimental foreground, on-device recognition sessions. Never starts at boot. */
public class WatchService extends Service {
 final Handler h=new Handler(Looper.getMainLooper());
 PersianEar ear; boolean running;
 static final String CHANNEL="kara-watch";
 public IBinder onBind(Intent i){return null;}
 Notification notification(String text, PendingIntent open){PendingIntent stop=PendingIntent.getService(this,9,new Intent(this,WatchService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("کارا • گوش‌به‌زنگ").setContentText(text).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open).addAction(android.R.drawable.ic_delete,"توقف",stop).build();}
 void note(String s,PendingIntent p){getSystemService(NotificationManager.class).notify(51,notification(s,p));}
 public int onStartCommand(Intent i,int flags,int id){if(i!=null&&"stop".equals(i.getAction())){running=false;stopSelf();return START_NOT_STICKY;}if(running)return START_NOT_STICKY;
 getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL,"گوش‌به‌زنگ کارا",NotificationManager.IMPORTANCE_LOW));
 startForeground(51,notification("آمادهٔ شنیدن فرمان تماس",null));running=true;listen();return START_NOT_STICKY;}
 void drop(){if(ear!=null)ear.stop();ear=null;}
 void later(long ms){if(running)h.postDelayed(this::listen,ms);}
 void status(String s){WatchSetup.prefs(this).edit().putString("earStatus",s).apply();}
 void fail(String reason){status(reason);Toast.makeText(this,reason,Toast.LENGTH_LONG).show();running=false;stopSelf();}
 void listen(){if(!running)return;drop();status("در حال آماده‌سازی مدل فارسی داخلی");ear=new PersianEar();ear.start(this,false,new PersianEar.Events(){public void ready(){if(running)status("مدل فارسی داخلی آمادهٔ شنیدن است");}public void result(String text){if(running)heard(text);}public void error(String msg){if(running)fail(msg);}});}
 void heard(String raw){status("گفتار دریافت شد");String s=raw.replace('ي','ی').replace('ك','ک').replaceAll("[،؟!.,‌]"," ").trim().replaceAll("\\s+"," ");callCommand(s);later(350);}
 @SuppressWarnings("deprecation") boolean callCommand(String s){
 boolean answer=s.matches("کارا تماس (?:(?:رو|را) )?وصل کن"),end=s.matches("کارا تماس (رو|را) قطع کن"),speaker=s.equals("کارا بزن روی بلندگو");
 if(!answer&&!end&&!speaker)return false;
 try{if(checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new SecurityException();
 int state=getSystemService(android.telephony.TelephonyManager.class).getCallState();boolean ring=state==android.telephony.TelephonyManager.CALL_STATE_RINGING,active=state==android.telephony.TelephonyManager.CALL_STATE_OFFHOOK;
 android.telecom.TelecomManager tel=getSystemService(android.telecom.TelecomManager.class);
 if(answer&&ring)tel.acceptRingingCall();else if(end&&(active||ring)){if(!tel.endCall())note("سیستم تماس را قطع نکرد",null);}else if(speaker&&active&&Build.VERSION.SDK_INT>=31){android.media.AudioManager audio=getSystemService(android.media.AudioManager.class);boolean ok=false;for(android.media.AudioDeviceInfo d:audio.getAvailableCommunicationDevices())if(d.getType()==android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER){ok=audio.setCommunicationDevice(d);break;}if(ok){routed=true;h.removeCallbacks(routeCheck);h.postDelayed(routeCheck,500);}else note("تغییر مسیر صدای تماس پذیرفته نشد",null);}
 }catch(RuntimeException e){note("فرمان اجرا نشد؛ مجوز یا دسترسی کنترل تماس در دسترس نیست",null);}return true;}
 boolean routed;void clearRoute(){if(routed){routed=false;try{getSystemService(android.media.AudioManager.class).clearCommunicationDevice();}catch(RuntimeException ignored){}}}
 final Runnable routeCheck=new Runnable(){public void run(){try{if(getSystemService(android.telephony.TelephonyManager.class).getCallState()==android.telephony.TelephonyManager.CALL_STATE_OFFHOOK){h.postDelayed(this,500);return;}}catch(RuntimeException ignored){}clearRoute();}};
 public void onDestroy(){clearRoute();running=false;h.removeCallbacksAndMessages(null);drop();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
