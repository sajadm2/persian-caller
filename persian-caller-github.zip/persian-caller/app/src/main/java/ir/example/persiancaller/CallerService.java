package ir.example.persiancaller;
import android.telecom.Call;
import android.telecom.CallScreeningService;
public class CallerService extends CallScreeningService {
    @Override public void onScreenCall(Call.Details details) {
        if (details.getCallDirection() != Call.Details.DIRECTION_INCOMING) return;
        // Never block or delay a call while resolving a name or initializing speech.
        respondToCall(details, new CallResponse.Builder().build());
        String number = details.getHandle() == null ? "" : details.getHandle().getSchemeSpecificPart();
        String name = Contacts.lookup(this, number);
        Speaker.play(this, number, name == null ? "شماره ناشناس تماس می‌گیرد" : name + " تماس می‌گیرد", message -> android.util.Log.i("PersianCaller", message));
    }
}
