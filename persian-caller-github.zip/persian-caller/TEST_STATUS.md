# Validation status — 0.3

User reports installation, test voice and incoming caller announcement worked in the previous version on their phone. Version 0.3 has NOT been compiled or device-tested here. New repeat, phone-state polling and audio-focus behavior require device testing, especially on Android 15, dual-SIM and call waiting.


This delivery contains source projects, NOT a built APK.

## Reviewed / checked
- Python preparation script passes `python3 -m py_compile`.
- Full `python3 scripts/prepare_voice.py` run succeeded with the locally cached archives; final output: `Offline Persian model and native engine ready.`
- Model/runtime archive SHA-256 values are pinned and verified before extraction.
- Archive extraction copies regular files only, rejects traversal paths, and selects ARM64/ARMv7 libraries.
- Kotlin render calls were manually compared with the bundled upstream Tts.kt signatures.
- Java calls the Kotlin object through `@JvmStatic`; speech synthesis runs on a serial worker rather than the UI/telecom callback.
- Android manifest was parsed and has no INTERNET permission. Minimum supported API is 29.
- GitHub workflow uses Java 17, Gradle 8.9, Android SDK 35, AGP 8.7.3 and Kotlin 2.0.21.
- Third-party notices are copied into APK assets by the preparation script.

## Not verified
- Android compilation: environment does not provide Java/Gradle/Android SDK. No successful APK build is claimed.
- Native engine execution, model synthesis or Persian pronunciation on an Android device.
- Incoming calls, locked-screen/background behavior, Bluetooth, DND, phone-vendor power management or 16KB page-size compatibility.
- Complete public-distribution license compliance of all native transitive dependencies.

## Acceptance checks on your phone
1. Build successfully in GitHub Actions; download and install the debug APK.
2. With networking disabled, use Test Voice, first without selecting a contact and then with a Persian-named contact.
3. Verify custom audio import, playback and deletion.
4. Allow contacts and select this app for call screening; test known and unknown incoming numbers from another phone.
5. Repeat with screen locked, after reboot, in silent/vibrate mode and through your usual headset.
6. Grant phone-state permission and verify four-second gaps after speech, stopping on answer/reject, and the 60-second maximum. Without permission verify single playback. Check whether the phone honors audio ducking; it may not.
7. Test fresh installation and later updates; debug-signature changes may require uninstalling the previous build.
