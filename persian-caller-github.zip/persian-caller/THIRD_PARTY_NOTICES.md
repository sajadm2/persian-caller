# Third-party notices

Project-specific caller application code is offered under GPL-3.0-or-later (see LICENSE), in view of the bundled speech stack's GPL components. Upstream files retain their own licenses. This prototype is not a completed redistribution-compliance audit; review all native transitive dependencies and provide corresponding source/build materials as required before distributing binaries publicly.

## Persian voice
- Name: fa/haaniye_low (single-speaker Persian, low-quality model)
- Original: https://github.com/MycroftAI/mimic3-voices/tree/master/voices/fa/haaniye_low
- Original declared license: CC-0; reproduced in licenses/VOICE-LICENSE.
- Converted artifact: https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-fa-haaniye_low.tar.bz2
- SHA256: 0a329e886eff1d0b4ec0b503a36fd7d8ce218c2ab7e69c068a02ebc039c6eaa1
- Model is copied unchanged; config/phonemizer data in its archive remain upstream material.

## sherpa-onnx
- Copyright Xiaomi and respective upstream contributors; Apache-2.0.
- Version: v1.12.20.
- Kotlin API Tts.kt is copied unmodified from sherpa-onnx/kotlin-api/Tts.kt.
- Source and build instructions: https://github.com/k2-fsa/sherpa-onnx/tree/v1.12.20
- Native artifact: sherpa-onnx-v1.12.20-android.tar.bz2 from the official release.
- SHA256: 5fb837e72c9dae6fe06d208dc97f2f6d715f7e5e476a6e36d1549e49c7e209d4
- License reproduced in licenses/SHERPA-ONNX-LICENSE.

## ONNX Runtime
- Copyright Microsoft Corporation; MIT license (licenses/ONNXRUNTIME-LICENSE).
- Source: https://github.com/microsoft/onnxruntime
- libonnxruntime.so is provided by the above sherpa-onnx native release. Consult that release's build definitions for the exact dependency revision; the included MIT license text was retrieved from the upstream v1.17.1 tree, not evidence of the binary's version.

## eSpeak NG and transitive dependencies
- eSpeak NG uses GPL-3.0-or-later; license text included in licenses/ESPEAK-NG-COPYING.
- Source: https://github.com/espeak-ng/espeak-ng
- The sherpa-onnx VITS/Piper phonemizer uses eSpeak-derived native code/data. Archive data and prebuilt binaries are not all Apache-licensed merely because sherpa-onnx is Apache-licensed.
- Exact dependency revisions and build recipes must be obtained from the matching sherpa-onnx source/build configuration for a compliant public binary distribution. Include additional upstream notices as required; links alone do not replace all corresponding-source obligations.
