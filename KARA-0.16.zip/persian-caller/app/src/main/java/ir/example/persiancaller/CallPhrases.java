package ir.example.persiancaller;

final class CallPhrases {
    static String normalize(String raw){return raw.replace('ي','ی').replace('ك','ک').replaceAll("[،؟!.,‌]"," ").trim().replaceAll("\\s+"," ");}
    static boolean asksWho(String s){return s.matches("(?:کارا )?(?:کی|چه کسی) (?:داره )?زنگ (?:می ?زنه|می ?زند)");}
    static boolean answers(String s){return s.matches("(?:کارا )?(?:لطفا )?(?:(?:تماس|تلفن|گوشی)(?: رو| را)? )?(?:وصل(?:ش)? (?:کن|بشه)|جواب(?:ش)? (?:بده|بدید)|پاسخ بده|بردار)");}
}
