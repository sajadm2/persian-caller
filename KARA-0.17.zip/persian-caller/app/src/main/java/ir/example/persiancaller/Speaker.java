package ir.example.persiancaller;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import java.io.File;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

final class Speaker {
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static MediaPlayer player;
    private static AudioManager manager;
    private static AudioFocusRequest focus;
    private static volatile int generation;
    private static boolean incoming, warmed;
    static void warm(Context context) {
        if (warmed) return; warmed = true;
        Context c = context.getApplicationContext();
        worker.execute(() -> { try { EmbeddedVoice.warm(c); } catch (Exception | LinkageError ignored) { } });
    }
    interface Result { void show(String message); }

    static void play(Context c, String number, String text, Result result) {
        begin(c, number, text, result, false);
    }
    private static Runnable onDone;
    static void stopCall(){ if(incoming) finish(); }
    static void announceCall(Context c, String number, String text, Result result, Runnable done) {
        beginInternal(c, number, text, result, true, done);
    }
    private static void begin(Context context, String number, String text, Result result, boolean call) {
        beginInternal(context,number,text,result,call,null);
    }
    private static Runnable completed;
    static void question(Context c, String text, boolean active, Result result, Runnable heard, Runnable finished){
        beginInternal(c,"",text,result,true,finished,active,heard);
    }
    private static void beginInternal(Context context,String number,String text,Result result,boolean call,Runnable done){beginInternal(context,number,text,result,call,done,false,null);}
    private static void beginInternal(Context context,String number,String text,Result result,boolean call,Runnable done,boolean active,Runnable heard){
        Context c = context.getApplicationContext();
        {
            finish();
            final int token = generation;
            boolean monitor = call && c.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
            completed=heard; onDone=done; incoming=call;
            if (!audible(c)) { finish(); result.show("گوشی در حالت بی‌صدا یا لرزش است."); return; }
            result.show("آماده‌سازی صدا");
            // A hard bound also protects against missed phone-state changes.
            handler.postDelayed(() -> { if (generation == token) finish(); }, call ? 60000 : 30000);
            if (monitor) watchCall(c, token, active);
            worker.execute(() -> {
                if (generation != token) return;
                try {
                    String saved = heard!=null ? null : c.getSharedPreferences("audio", 0).getString(Contacts.key(number), null);
                    File audio = saved == null ? null : new File(c.getFilesDir(), saved);
                    if (audio == null || !audio.isFile()) audio = EmbeddedVoice.render(c, text);
                    File ready = audio;
                    handler.post(() -> playFile(c, ready, token, result));
                } catch (Exception | LinkageError e) {
                    handler.post(() -> { if (generation == token) { finish(); result.show("خطای موتور: " + e.getMessage()); } });
                }
            });
        }
    }
    @SuppressWarnings("deprecation")
    private static void watchCall(Context c, int token, boolean active) {
        if (generation != token) return;
        try {
            int state = c.getSystemService(TelephonyManager.class).getCallState();
            boolean ringing = state == (active ? TelephonyManager.CALL_STATE_OFFHOOK : TelephonyManager.CALL_STATE_RINGING);
            if (!ringing || !audible(c)) {
                finish(); return;
            }
            handler.postDelayed(() -> watchCall(c, token, active), 150);
        } catch (SecurityException e) { finish(); }
    }
    private static void playFile(Context c, File audio, int token, Result result) {
        if (generation != token) return;
        if (!audible(c)) { finish(); return; }
        try {
            releasePlayback();
            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
            manager = c.getSystemService(AudioManager.class);
            focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attributes)
                .setOnAudioFocusChangeListener(change -> {
                    if (generation == token && (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT)) finish();
                }, handler).build();
            int granted = manager.requestAudioFocus(focus);
            player = new MediaPlayer();
            MediaPlayer current = player;
            player.setAudioAttributes(attributes);
            player.setVolume(1f, 1f);
            player.setDataSource(audio.getPath());
            player.setOnCompletionListener(p -> {
                if (generation != token || player != p) return;
                if(completed!=null)completed.run();
                finish();
            });
            player.setOnErrorListener((p, a, b) -> {
                if (generation == token) { finish(); result.show("خطا در پخش صدا"); }
                return true;
            });
            player.setOnPreparedListener(p -> {
                if (generation != token || player != p) return;
                if (!audible(c)) { finish(); return; }
                p.start();
                result.show(granted == AudioManager.AUDIOFOCUS_REQUEST_GRANTED ? "پخش اعلان فارسی" : "پخش اعلان؛ اولویت صدا توسط سیستم پذیرفته نشد");
                handler.postDelayed(() -> { if (generation == token && player == current) finish(); }, 15000);
            });
            player.prepareAsync();
        } catch (Exception e) { finish(); result.show("خطای پخش: " + e.getMessage()); }
    }
    private static boolean audible(Context c) {
        AudioManager am=c.getSystemService(AudioManager.class);
        return am.getRingerMode()==AudioManager.RINGER_MODE_NORMAL && !am.isStreamMute(AudioManager.STREAM_RING) && am.getStreamVolume(AudioManager.STREAM_RING)>0;
    }
    private static void releasePlayback() {
        RingLevel.end();
        if (player != null) { player.release(); player = null; }
        if (manager != null && focus != null) manager.abandonAudioFocusRequest(focus);
        focus = null;
    }
    private static void finish() { completed=null; generation++; releasePlayback(); incoming=false; Runnable done=onDone; onDone=null; if(done!=null)done.run(); }
}
