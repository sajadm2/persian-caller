package ir.example.persiancaller;

final class CallPhrases {
    static String normalize(String raw){return raw.replace('ي','ی').replace('ك','ک').replaceAll("[،؟!.,‌]"," ").trim().replaceAll("\\s+"," ");}
    static boolean asksWho(String s){return s.matches("(?:کارا )?(?:لطفا )?(?:ببین |بگو )?(?:کیه|کی هست|(?:کی|چه کسی) (?:داره )?(?:زنگ (?:می ?زنه|می ?زند|زده)|پشت خط(?:ه| است))|(?:اسمش|نامش) (?:چیه|چی هست)|(?:شمارش|شماره ?اش|شماره ش) (?:چنده|چیه))");}
    static boolean yes(String s){return s.matches("(?:کارا )?(?:بله|آره|اره)");}
    static boolean no(String s){return s.matches("(?:کارا )?(?:نه|خیر)");}
    static boolean answers(String s){return s.matches("(?:کارا )?(?:لطفا )?(?:(?:تماس|تلفن|گوشی)(?: رو| را)? )?(?:وصل(?:ش)? (?:کن|بشه)|جواب(?:ش)? (?:بده|بدید)|پاسخ بده|بردار)");}
}
