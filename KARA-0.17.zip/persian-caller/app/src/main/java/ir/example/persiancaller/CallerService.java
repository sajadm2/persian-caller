package ir.example.persiancaller;
import android.telecom.Call;
import android.telecom.CallScreeningService;
public class CallerService extends CallScreeningService {
    // Both services run on the main thread in the same process. Never persist caller identity.
    static boolean armed;
    static String currentNumber="";
    @Override public void onScreenCall(Call.Details details) {
        if (details.getCallDirection() != Call.Details.DIRECTION_INCOMING) return;
        // Never block or delay a call while resolving a name or initializing speech.
        respondToCall(details, new CallResponse.Builder().build());
        String number = details.getHandle() == null ? "" : details.getHandle().getSchemeSpecificPart();
        if (armed) currentNumber = number == null ? "" : number;
    }
}
