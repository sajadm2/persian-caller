package ir.example.persiancaller;
import android.app.*;
import android.content.*;
import android.os.*;
import android.media.MediaPlayer;
import android.speech.*;
import android.widget.Toast;
import java.util.*;
import java.io.File;
import java.util.concurrent.*;

/** Experimental foreground, on-device recognition sessions. Never starts at boot. */
public class WatchService extends Service {
 final Handler h=new Handler(Looper.getMainLooper());
 PersianEar ear; boolean running;
 static final String CHANNEL="kara-watch";
 public IBinder onBind(Intent i){return null;}
 Notification notification(String text, PendingIntent open){PendingIntent stop=PendingIntent.getService(this,9,new Intent(this,WatchService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("کارا • گوش‌به‌زنگ").setContentText(text).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open).addAction(android.R.drawable.ic_delete,"توقف",stop).build();}
 void note(String s,PendingIntent p){getSystemService(NotificationManager.class).notify(51,notification(s,p));}
 public int onStartCommand(Intent i,int flags,int id){if(i!=null&&"stop".equals(i.getAction())){running=false;stopSelf();return START_NOT_STICKY;}if(running)return START_NOT_STICKY;
 getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL,"گوش‌به‌زنگ کارا",NotificationManager.IMPORTANCE_LOW));
 startForeground(51,notification(WAIT,null));running=true;CallerService.armed=true;status(WAIT);
 try{phone=getSystemService(android.telephony.TelephonyManager.class);phone.listen(states,android.telephony.PhoneStateListener.LISTEN_CALL_STATE);}catch(RuntimeException e){fail("پایش تماس ممکن نشد؛ مجوز وضعیت تلفن را بررسی کن");}return START_NOT_STICKY;}
 static final String WAIT="منتظر تماس ورودی؛ میکروفون خاموش است";
 android.telephony.TelephonyManager phone; boolean incoming,window;
 final Runnable resume=this::listen, timeout=()->quiet("پایان فرصت فرمان؛ میکروفون خاموش است");
 int epoch,phase; boolean answeredHere; // phase 1: answer confirmation, 2: speaker confirmation
 String identity(){String n=CallerService.currentNumber, name=Contacts.lookup(this,n);return name!=null?name:n.isEmpty()?"تماس‌گیرنده ناشناس":SpokenNumber.format(n);}
 void ask(boolean active){final int token=epoch;String text=active?"صدا رو بذارم روی بلندگو؟":identity()+" زنگ می‌زنه. جواب بدم؟";
 Speaker.question(this,text,active,this::status,()->{if(epoch==token&&window)phase=active?2:1;},()->{if(epoch==token&&window){later(250);if(active)h.postDelayed(timeout,10000);}});}
 final android.telephony.PhoneStateListener states=new android.telephony.PhoneStateListener(){public void onCallStateChanged(int state,String ignored){if(!running)return;
 if(state==1){if(!incoming){int token=++epoch;incoming=true;window=true;phase=0;answeredHere=false;note("تماس ورودی",null);h.postDelayed(()->{if(epoch==token&&running&&window)ask(false);},400);}}else if(state==2){if(!incoming)return;incoming=false;++epoch;phase=0;h.removeCallbacks(resume);drop();Speaker.stopCall();CallerService.currentNumber="";if(answeredHere&&window)ask(true);else quiet(WAIT);answeredHere=false;}else{++epoch;phase=0;answeredHere=false;incoming=false;CallerService.currentNumber="";clearRoute();quiet(WAIT);Speaker.stopCall();}}};
 void quiet(String msg){window=false;h.removeCallbacks(resume);h.removeCallbacks(timeout);drop();status(msg);note(msg,null);}
 void drop(){if(ear!=null)ear.stop();ear=null;}
 void later(long ms){if(running&&window)h.postDelayed(resume,ms);}
 void status(String s){WatchSetup.prefs(this).edit().putString("earStatus",s).apply();}
 void fail(String reason){status(reason);Toast.makeText(this,reason,Toast.LENGTH_LONG).show();running=false;stopSelf();}
 void listen(){if(!running||!window)return;drop();status("در حال آماده‌سازی مدل فارسی داخلی");ear=new PersianEar();ear.start(this,false,new PersianEar.Events(){public void ready(){if(running)status("مدل فارسی داخلی آمادهٔ شنیدن است");}public void result(String text){if(running)heard(text);}public void error(String msg){if(running&&window)quiet(msg);}});}
 void heard(String raw){status("گفتار دریافت شد");String s=CallPhrases.normalize(raw);
 if(phase!=0&&CallPhrases.no(s)){phase=0;if(!incoming){quiet(WAIT);return;}later(350);return;}
 if(phase!=0&&CallPhrases.yes(s)){int p=phase;phase=0;callCommand(p==1?"جواب بده":"کارا بزن روی بلندگو");if(p==2)quiet(WAIT);else later(350);return;}
 if(CallPhrases.asksWho(s)&&incoming&&phone.getCallState()==android.telephony.TelephonyManager.CALL_STATE_RINGING){String number=CallerService.currentNumber,name=Contacts.lookup(this,number);String text=name!=null?name+" زنگ می‌زند":number.isEmpty()?"تماس‌گیرنده ناشناس است":SpokenNumber.format(number)+" زنگ می‌زند";
 Speaker.announceCall(this,number,text,this::status,()->later(350));return;}callCommand(s);later(350);}
 @SuppressWarnings("deprecation") boolean callCommand(String s){
 boolean answer=CallPhrases.answers(s),end=s.matches("کارا تماس (رو|را) قطع کن"),speaker=s.equals("کارا بزن روی بلندگو");
 if(!answer&&!end&&!speaker)return false;
 try{if(checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new SecurityException();
 int state=getSystemService(android.telephony.TelephonyManager.class).getCallState();boolean ring=state==android.telephony.TelephonyManager.CALL_STATE_RINGING,active=state==android.telephony.TelephonyManager.CALL_STATE_OFFHOOK;
 android.telecom.TelecomManager tel=getSystemService(android.telecom.TelecomManager.class);
 if(answer&&ring){tel.acceptRingingCall();answeredHere=true;}else if(end&&(active||ring)){if(!tel.endCall())note("سیستم تماس را قطع نکرد",null);}else if(speaker&&active&&Build.VERSION.SDK_INT>=31){android.media.AudioManager audio=getSystemService(android.media.AudioManager.class);boolean ok=false;for(android.media.AudioDeviceInfo d:audio.getAvailableCommunicationDevices())if(d.getType()==android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER){ok=audio.setCommunicationDevice(d);break;}if(ok){routed=true;}else note("تغییر مسیر صدای تماس پذیرفته نشد",null);}
 }catch(RuntimeException e){note("فرمان اجرا نشد؛ مجوز یا دسترسی کنترل تماس در دسترس نیست",null);}return true;}
 boolean routed;void clearRoute(){if(routed){routed=false;try{getSystemService(android.media.AudioManager.class).clearCommunicationDevice();}catch(RuntimeException ignored){}}}
 public void onDestroy(){running=false;CallerService.armed=false;CallerService.currentNumber="";Speaker.stopCall();if(phone!=null)try{phone.listen(states,android.telephony.PhoneStateListener.LISTEN_NONE);}catch(RuntimeException ignored){}clearRoute();h.removeCallbacksAndMessages(null);drop();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
