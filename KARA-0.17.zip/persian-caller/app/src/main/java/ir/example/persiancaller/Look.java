package ir.example.persiancaller;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
final class Look {
 static int dp(Context c,int n){return Math.round(c.getResources().getDisplayMetrics().density*n);}
 static GradientDrawable tile(Context c,int fill,int line){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(c,14));g.setStroke(dp(c,1),line);return g;}
 static void header(LinearLayout l){Context c=l.getContext();ImageView k=new ImageView(c);k.setImageResource(R.drawable.kara_mark);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(c,50),dp(c,50));p.gravity=Gravity.CENTER;l.addView(k,p);TextView t=new TextView(c);t.setText("KARA");t.setLetterSpacing(.14f);t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);t.setTextSize(25);t.setGravity(Gravity.CENTER);l.addView(t);TextView sub=new TextView(c);sub.setText("دستیار فارسی آفلاین");sub.setGravity(Gravity.CENTER);sub.setTextColor(0xffb2c8c3);sub.setPadding(0,0,0,dp(c,12));l.addView(sub);}
 static void safe(View v){int l=v.getPaddingLeft(),t=v.getPaddingTop(),r=v.getPaddingRight(),b=v.getPaddingBottom();if(android.os.Build.VERSION.SDK_INT>=35){v.setOnApplyWindowInsetsListener((w,i)->{android.graphics.Insets z=i.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());w.setPadding(l+z.left,t+z.top,r+z.right,b+z.bottom);return i;});v.requestApplyInsets();}}
}
