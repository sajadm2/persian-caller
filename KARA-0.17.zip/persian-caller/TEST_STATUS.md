Source checks only; APK build and device tests pending.
