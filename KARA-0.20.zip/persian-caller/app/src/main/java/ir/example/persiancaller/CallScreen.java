package ir.example.persiancaller;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Bundle;
import android.telecom.*;
import android.view.*;
import android.widget.*;
import java.util.HashMap;

@SuppressWarnings("deprecation")
public class CallScreen extends Activity {
 private static final int WHITE=0xffeff9f5,MINT=0xff97ecd0,SOFT=0xffc5d7d6;
 private LinearLayout page; private final Runnable redraw=this::render;
 private final HashMap<String,String> names=new HashMap<>();
 int dp(int n){return Look.dp(this,n);}
 public void onCreate(Bundle b){super.onCreate(b);ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff275856,0xff16333e,0xff111924,0xff131822}));page=new LinearLayout(this);page.setOrientation(1);page.setPadding(dp(20),dp(24),dp(20),dp(24));scroll.addView(page);setContentView(scroll);Look.safe(scroll);}
 public void onResume(){super.onResume();KaraCalls.refresh=redraw;render();}public void onPause(){if(KaraCalls.refresh==redraw)KaraCalls.refresh=null;super.onPause();}
 GradientDrawable oval(int color){GradientDrawable g=new GradientDrawable();g.setShape(GradientDrawable.OVAL);g.setColor(color);return g;}
 TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t;}
 void gap(LinearLayout box,int n){box.addView(new Space(this),1,dp(n));}
 void flex(LinearLayout box,int min){box.addView(new Space(this),new LinearLayout.LayoutParams(1,dp(min),1));}
 void action(LinearLayout row,String label,int kind,int color,Runnable run){LinearLayout col=new LinearLayout(this);col.setOrientation(1);col.setGravity(Gravity.CENTER);row.addView(col,new LinearLayout.LayoutParams(0,-2,1));Glyph icon=new Glyph(kind);icon.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55ffffff),oval(color),null));icon.setElevation(dp(3));icon.setFocusable(true);icon.setContentDescription(label);icon.setOnClickListener(v->run.run());col.addView(icon,dp(68),dp(68));gap(col,9);TextView caption=text(label,15,WHITE);caption.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);col.addView(caption);}
 class Glyph extends View {int kind;Paint p=new Paint(1);Glyph(int k){super(CallScreen.this);kind=k;}protected void onDraw(Canvas c){super.onDraw(c);c.save();c.scale(getWidth()/64f,getHeight()/64f);p.setColor(0xffffffff);p.setStyle(Paint.Style.FILL);Path s=new Path();if(kind<2){c.rotate(kind==1?135:0,32,32);s.moveTo(20,17);s.quadTo(16,18,18,26);s.cubicTo(21,37,31,47,43,47);s.quadTo(48,47,48,40);s.lineTo(39,36);s.lineTo(35,40);s.quadTo(28,36,25,29);s.lineTo(29,25);s.lineTo(25,17);s.close();c.drawPath(s,p);}else{s.moveTo(17,28);s.lineTo(24,28);s.lineTo(33,20);s.lineTo(33,44);s.lineTo(24,36);s.lineTo(17,36);s.close();c.drawPath(s,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.6f);c.drawArc(24,23,43,41,-56,112,false,p);c.drawArc(18,16,50,48,-50,100,false,p);}c.restore();}}
 String state(int s){switch(s){case Call.STATE_RINGING:return "تماس ورودی";case Call.STATE_ACTIVE:return "در حال مکالمه";case Call.STATE_HOLDING:return "تماس در انتظار";case Call.STATE_DISCONNECTED:return "تماس پایان یافت";default:return "در حال برقراری تماس";}}
 void render(){KaraCalls k=KaraCalls.live;if(k==null||k.calls.isEmpty()){finish();return;}page.removeAllViews();TextView brand=text("K A R A",14,MINT);page.addView(brand);for(Call c:k.calls){LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setGravity(Gravity.CENTER_HORIZONTAL);page.addView(card,new LinearLayout.LayoutParams(-1,-2,1));flex(card,20);android.net.Uri u=c.getDetails().getHandle();String num=u==null?"":u.getSchemeSpecificPart();if(num==null)num="";if(!names.containsKey(num))names.put(num,Contacts.lookup(this,num));String name=names.get(num);boolean known=name!=null&&!name.trim().isEmpty();String title=known?name.trim():num.isEmpty()?"ناشناس":num;
 FrameLayout halo=new FrameLayout(this);GradientDrawable ring=oval(0x183cf3bd);ring.setStroke(dp(1),0x5097ecd0);halo.setBackground(ring);card.addView(halo,dp(110),dp(110));TextView av=text(known?title.substring(0,title.offsetByCodePoints(0,1)):"☎",38,WHITE);av.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);av.setBackground(oval(0xff397b74));halo.addView(av,new FrameLayout.LayoutParams(dp(88),dp(88),Gravity.CENTER));gap(card,20);TextView who=text(title,32,WHITE);who.setTypeface(Typeface.create("sans-serif-medium",0));card.addView(who);if(known)card.addView(text(num,16,SOFT));gap(card,8);card.addView(text(state(c.getState()),17,MINT));flex(card,34);
 LinearLayout row=new LinearLayout(this);row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);card.addView(row,new LinearLayout.LayoutParams(-1,-2));if(c.getState()==Call.STATE_RINGING){action(row,"رد تماس",1,0xffcb404c,()->c.reject(false,null));action(row,"پاسخ دستی",0,0xff158257,()->k.manual(c));}else{action(row,"قطع تماس",1,0xffcb404c,c::disconnect);if(c.getState()==Call.STATE_ACTIVE){CallAudioState a=k.getCallAudioState();boolean sp=a!=null&&a.getRoute()==CallAudioState.ROUTE_SPEAKER;action(row,sp?"برگشت به گوشی":"بلندگو",2,sp?0xff158257:0xff435865,()->k.route(!sp));}}gap(card,12);}if(!k.routing.isEmpty())page.addView(text(k.routing,14,SOFT));}
}
