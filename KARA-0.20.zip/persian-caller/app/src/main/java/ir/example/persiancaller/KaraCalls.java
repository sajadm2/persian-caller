package ir.example.persiancaller;
import android.app.*;
import android.content.*;
import android.os.Handler;
import android.os.Looper;
import android.telecom.*;
import java.util.*;

/** All state belongs to Telecom's Call objects and is accessed on the main thread. */
@SuppressWarnings("deprecation")
public class KaraCalls extends InCallService {
 static KaraCalls live; static Runnable refresh;
 final List<Call> calls=new ArrayList<>(); Call pending;
 static final int ID=72; final Handler h=new Handler(Looper.getMainLooper());
 String routing=""; boolean waiting; final Runnable verify=()->{if(waiting){waiting=false;routing="بلندگو تأیید نشد؛ مسیر صدا را بررسی کن";draw();}};
 final Call.Callback cb=new Call.Callback(){@Override public void onStateChanged(Call c,int state){if(c==pending){if(state==Call.STATE_ACTIVE){pending=null;route(true);}else if(state!=Call.STATE_RINGING&&state!=Call.STATE_CONNECTING)pending=null;}update();}};
 void draw(){if(refresh!=null)refresh.run();}
 @Override public void onCreate(){super.onCreate();live=this;getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("kara-incoming","تماس کارا",NotificationManager.IMPORTANCE_HIGH));}
 @Override public void onCallAdded(Call c){super.onCallAdded(c);calls.add(c);c.registerCallback(cb,h);update();}
 @Override public void onCallRemoved(Call c){c.unregisterCallback(cb);calls.remove(c);if(pending==c)pending=null;if(calls.isEmpty()){waiting=false;routing="";h.removeCallbacks(verify);}update();super.onCallRemoved(c);}
 boolean voiceAnswer(){Call ring=null;for(Call c:calls)if(c.getState()==Call.STATE_RINGING){if(ring!=null)return false;ring=c;}if(ring==null)return false;pending=ring;try{ring.answer(VideoProfile.STATE_AUDIO_ONLY);return true;}catch(RuntimeException e){pending=null;return false;}}
 void manual(Call c){if(pending==c)pending=null;if(c.getState()==Call.STATE_RINGING)c.answer(VideoProfile.STATE_AUDIO_ONLY);}
 void route(boolean speaker){h.removeCallbacks(verify);waiting=speaker;try{setAudioRoute(speaker?CallAudioState.ROUTE_SPEAKER:CallAudioState.ROUTE_EARPIECE);routing=speaker?"درخواست بلندگو ارسال شد":"درخواست گوشی ارسال شد";if(speaker)h.postDelayed(verify,3500);}catch(RuntimeException e){waiting=false;routing="تغییر مسیر صدا ممکن نشد";}draw();}
 @Override public void onCallAudioStateChanged(CallAudioState a){super.onCallAudioStateChanged(a);if(a!=null&&a.getRoute()==CallAudioState.ROUTE_SPEAKER){waiting=false;h.removeCallbacks(verify);routing="بلندگو روشن است";}else if(!waiting)routing="";draw();}
 void update(){draw();NotificationManager nm=getSystemService(NotificationManager.class);if(calls.isEmpty()){nm.cancel(ID);return;}boolean ringing=false;for(Call c:calls)if(c.getState()==Call.STATE_RINGING)ringing=true;
 PendingIntent open=PendingIntent.getActivity(this,ID,new Intent(this,CallScreen.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
 Notification.Builder n=new Notification.Builder(this,"kara-incoming").setSmallIcon(android.R.drawable.sym_action_call).setCategory(Notification.CATEGORY_CALL).setContentTitle(ringing?"تماس ورودی کارا":"تماس کارا").setContentText("برای کنترل تماس لمس کن").setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true);if(ringing)n.setFullScreenIntent(open,true);nm.notify(ID,n.build());}
 @Override public void onBringToForeground(boolean keypad){startActivity(new Intent(this,CallScreen.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
 @Override public void onDestroy(){h.removeCallbacksAndMessages(null);for(Call c:calls)c.unregisterCallback(cb);calls.clear();pending=null;live=null;getSystemService(NotificationManager.class).cancel(ID);draw();super.onDestroy();}
}
