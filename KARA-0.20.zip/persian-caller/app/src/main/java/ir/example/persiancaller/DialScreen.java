package ir.example.persiancaller;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.net.Uri;
import android.telecom.TelecomManager;
import android.widget.*;
public class DialScreen extends Activity {
 EditText number;public void onCreate(Bundle b){super.onCreate(b);LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(32,80,32,32);setContentView(l);Look.header(l);number=new EditText(this);number.setSingleLine(true);number.setInputType(android.text.InputType.TYPE_CLASS_PHONE);number.setHint("شماره تلفن");Uri u=getIntent().getData();if(u!=null&&"tel".equals(u.getScheme()))number.setText(u.getSchemeSpecificPart());l.addView(number);Button call=new Button(this);call.setText("تماس");l.addView(call);call.setOnClickListener(v->{if(checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CALL_PHONE},1);return;}String n=number.getText().toString().trim();if(!n.isEmpty())try{getSystemService(TelecomManager.class).placeCall(Uri.fromParts("tel",n,null),new Bundle());}catch(RuntimeException e){Toast.makeText(this,"شماره‌گیری ممکن نشد",Toast.LENGTH_LONG).show();}});}
}
